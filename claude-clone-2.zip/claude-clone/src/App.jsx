import { useState, useRef, useEffect } from 'react';
import { Send, Plus, Settings, User, Bot } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import './App.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [model, setModel] = useState('claude-sonnet-4.6');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const chatEndRef = useRef(null);

  const models = [
    { id: 'claude-opus-4.6', name: 'Claude Opus 4.6' },
    { id: 'claude-sonnet-4.6', name: 'Claude Sonnet 4.6' },
    { id: 'claude-haiku-4.5', name: 'Claude Haiku' },
  ];

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/.netlify/functions/claude-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          messages: [...messages, userMessage],
          stream: false
        })
      });

      const data = await response.json();
      
      if (data.choices && data.choices[0]) {
        const assistantMessage = {
          role: 'assistant',
          content: data.choices[0].message.content
        };
        setMessages(prev => [...prev, assistantMessage]);
      }
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Sorry, there was an error connecting to the API.' 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="app">
      {/* Sidebar */}
      <div className={`sidebar ${sidebarOpen ? '' : 'closed'}`}>
        <div className="sidebar-header">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="toggle-btn">
            <Plus size={20} />
          </button>
          <h1>Claude Clone</h1>
        </div>
        
        <div className="new-chat">
          <button onClick={() => setMessages([])}>
            <Plus size={18} /> New Chat
          </button>
        </div>

        <div className="model-selector">
          <label>Model</label>
          <select value={model} onChange={(e) => setModel(e.target.value)}>
            {models.map(m => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>

        <div className="history">
          <p>Recent conversations</p>
          {/* Placeholder history */}
        </div>
      </div>

      {/* Main Chat */}
      <div className="chat-container">
        <header>
          <div className="header-left">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="menu-btn">
              ☰
            </button>
            <h2>{models.find(m => m.id === model)?.name}</h2>
          </div>
          <div className="header-right">
            <Settings size={20} />
            <User size={20} />
          </div>
        </header>

        <div className="messages">
          {messages.length === 0 ? (
            <div className="welcome">
              <Bot size={64} />
              <h1>How can I help you today?</h1>
              <p>Ask me anything. Powered by Bluesminds + Claude models.</p>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div key={idx} className={`message ${msg.role}`}>
                <div className="avatar">
                  {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
                </div>
                <div className="content">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              </div>
            ))
          )}
          {isLoading && <div className="message assistant">Thinking...</div>}
          <div ref={chatEndRef} />
        </div>

        <div className="input-area">
          <div className="input-wrapper">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Message Claude..."
              rows={1}
            />
            <button onClick={sendMessage} disabled={!input.trim() || isLoading}>
              <Send size={20} />
            </button>
          </div>
          <p className="disclaimer">Responses powered by Bluesminds API • Set your key in Netlify env vars</p>
        </div>
      </div>
    </div>
  );
}

export default App;
