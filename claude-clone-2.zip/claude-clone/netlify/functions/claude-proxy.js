exports.handler = async (event) => {
  const { BLUESMINDS_API_KEY } = process.env;
  
  if (!BLUESMINDS_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'API key not configured' })
    };
  }

  try {
    const body = JSON.parse(event.body);
    
    const response = await fetch('https://api.bluesminds.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${BLUESMINDS_API_KEY}`
      },
      body: JSON.stringify({
        model: body.model || 'claude-sonnet-4.6',
        messages: body.messages,
        stream: body.stream || false,
        temperature: body.temperature || 0.7,
        max_tokens: body.max_tokens || 4096
      })
    });

    const data = await response.json();
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
